package psa.naloga5;

public class Prim {
	int[][] data;
	int n;
	int i, j, d;
	boolean obiskano [];
	int prednik [];
	int raz [];
	int[] cost;
	
	 public Prim(int n) {
		  this.n=n;
		  obiskano = new boolean[n];
		  prednik = new int[n];
		  raz = new int[n];
		  data = new int[n][n];
		 }

	 public Prim(int[][] d) {
		  this.data=d;
		  this.n=data.length;
		  prednik=new int [n];
		  raz=new int[n];
		  obiskano=new boolean [n];
		  for (int i = 0; i < n; i++) 
		  {
		   for (int j = 0; j < n; j++) 
		   {
		    if(i!=j && (data[i][j]==0 || data[i][j]==-1 || data[i][j]==Integer.MIN_VALUE))
		    {
		     this.data[i][j]=Integer.MAX_VALUE;
		    }
		   }
		  }
		  
		 }


	public void addEdge(int i, int j, int d) {
		this.i = i;
		this.j = j;
		this.d = d;
		data[i][j] = d;
		data[j][i] = d;
	}

	public int MSTcost() {
		int cena=0;
		prim(0);
		for(int i=0;i<n;i++){
			cena=cena+cost[i];
		}
		return cena;
	}

	public int[] prim(int s) {
		
		for (int i=0; i<raz.length; i++) {
			          raz[i] = Integer.MAX_VALUE;
			 }
	        raz[s] = 0;
	       prednik[s] = s;
	 	

	        for (int i=0; i<raz.length; i++) {
	         int next = min (raz, obiskano);
	           obiskano[next] = true;
	  
	           // The edge from pred[next] to next is in the MST (if next!=s)
	 
	        
	         for (int j=0; j<data[next].length; j++) {
	            if(data[next][j] != 0 && !obiskano[j]){
	             if (raz[j] > data[next][j]) {
	                 raz[j] = data[next][j];
	                 prednik[j] = next;
	             }
	       }}
	        }cost = raz;
	        return prednik;  // (ignore pred[s]==0!)
	     }

		

	
	
	
	private static int min (int [] dist, boolean [] v) {
		int ena = Integer.MAX_VALUE;
		  int dva = -1;   
		   for (int i=0; i<dist.length; i++) {
	         if (!v[i] && dist[i]<ena) {dva=i; ena=dist[i];}
		      }
	      return dva;
		    }

}
