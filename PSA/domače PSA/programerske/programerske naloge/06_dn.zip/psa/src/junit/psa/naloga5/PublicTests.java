package psa.naloga5;

public class PublicTests {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Prim mst;
		
		mst = new Prim(9);
		
		mst.addEdge(0,1,4);
		mst.addEdge(0,7,8);
		mst.addEdge(1,2,8);
		mst.addEdge(1,7,11);
		mst.addEdge(2,8,2);
		mst.addEdge(2,3,7);
		mst.addEdge(2,5,4);
		mst.addEdge(3,4,9);
		mst.addEdge(3,5,14);
		mst.addEdge(4,5,10);
		mst.addEdge(5,6,2);
		mst.addEdge(6,8,6);
		mst.addEdge(6,7,1);
		mst.addEdge(7,8,7);
		
		int[] lala = mst.prim(0);
		System.out.print("Vozli��a: ");
		for (int i = 0; i < lala.length; i++) {
			System.out.print(i + " ");
			
		}
		System.out.println();
		System.out.print("   Star�: ");
		for (int i = 0; i < lala.length; i++) {
			System.out.print(lala[i] + " ");
		}
				
		System.out.println();
		System.out.println(mst.MSTcost());
		
		int[][] matrika = mst.data;
		Prim mst2 = new Prim(matrika);
		
		lala = mst2.prim(0);
		System.out.print("Vozli��a: ");
		for (int i = 0; i < lala.length; i++) {
			System.out.print(i + " ");
			
		}
		System.out.println();
		System.out.print("   Star�: ");
		for (int i = 0; i < lala.length; i++) {
			System.out.print(lala[i] + " ");
		}
		
		System.out.println();
		System.out.print("Skupna cena: ");
		System.out.print(mst2.MSTcost());
	}

}