package psa.naloga2;


public class UnionFind {
	public int[] id;
    private byte[] st;
    private int stevec;
    
    
	public UnionFind(int N){
	        if (N < 0) throw new IllegalArgumentException();
	        stevec=N;
	        id=new int[N];
	        st=new byte[N];
	        for (int i = 0; i < N; i++){
	            id[i]=i;
	            st[i]=0;
	        }
	    }

	
	/*
	 * Metoda sprejme index in vrne predstavnika mnozice, katere clan je index.
	 */
	public int find(int i) 
	{
		if (i<0 || i>=id.length) throw new IndexOutOfBoundsException();
        while (i != id[i]){
            id[i]=id[id[i]];
            i=id[i];
        }
        return i;
    }

	/*
	 * Metoda sprejme da indexa in naredi unijo
	 */
	
	public void unite(int p, int q) 
	{
        int j = find(q);
        int i = find(p);
        if (i == j) return;
        if (st[i] < st[j]) id[i] = j;
        else if (st[i] > st[j]) id[j] = i;
        else{
            id[j] = i;
            st[i]++;
        }
        
        stevec--;
    }
	
	/*
	 * Metoda vrne true, ce sta p in q v isti mnozici
	 */
	
	public boolean isInSameSet(int p, int q) 
	{
	return find(p) == find(q);
	}
	
	
	public int count() {
        return stevec;
    }
	
	
	public static void main(String[] args) {
    }
}
