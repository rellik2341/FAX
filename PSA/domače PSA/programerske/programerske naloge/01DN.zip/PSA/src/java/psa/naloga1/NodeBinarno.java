package psa.naloga1;

public class NodeBinarno {
	private static int counter;
	public int key;
	public NodeBinarno right;
	public NodeBinarno left;
	public NodeBinarno parent;

	public NodeBinarno(int elemen) {
		this.key = elemen;
		this.left = null;
		this.right = null;
		this.parent = null;
	}
	
	public boolean insert(NodeBinarno node) {
		int comp = this.compare(node);
		if (comp < 0){
			if (left == null){
				left = node;
				left.parent = this;
				return true;
			} else 
			{
				return left.insert(node);
			}
		} else if (comp > 0){
			if (right == null){
				right = node;
				right.parent = this;
				return true;
			} else{
				return right.insert(node);
			}
		} else {
			return false;
		}
	}
	
	public boolean search(NodeBinarno node) {
		int comp = this.compare(node);
		if (comp == 0)
		{
			return true;
		} else if (comp < 0){
			if (left == null)
			{
				return false;
			} else{
				return left.search(node);				
			}
		} else{
			if (right==null){
				return false;
			} else {
				
				return right.search(node);
			}
		}
	}
	
	public boolean delete(NodeBinarno node){
		int comp = this.compare(node);
		if (comp < 0) {
			if (left != null){
				return left.delete(node);
			} else {
				return false;
			}
		} else if (comp > 0){
			if (right != null) {
				return right.delete(node);
			} else {
				return false;
			}
		} else {
			if (left != null && right != null) {
				NodeBinarno minNode = right.getMin();
				this.key = minNode.key;
				right.delete(minNode);			
			} else if (parent.left == this){
				parent.left = (left != null ? left : right);
			} else if (parent.right == this){
				parent.right = (left != null ? left : right);
			}
			return true;
		}
	}
	
	public NodeBinarno getMin(){
		if (left == null){
			return this;
		} else 
		{
			return left.getMin();
		}
	}
	
	public int compare(NodeBinarno node) {
		counter++;
		return node.key - this.key;
	}
	
	public int getCounter() {
		return counter;
	}
	
	public void resetCounter() {
		counter=0;
	}
}