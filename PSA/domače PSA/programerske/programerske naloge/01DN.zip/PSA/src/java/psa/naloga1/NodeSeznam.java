package psa.naloga1;

public class NodeSeznam {
	private static int counter;
	private int key;
	private NodeSeznam head;

	public NodeSeznam(int elem) {
		this.key = elem;
		this.head = null;
	}
	
	public boolean insert(NodeSeznam node) {
		if (this.compare(node) == 0) {
			return false;
			
		} else if (head == null)
		{
			head = node;
			return true;
		} else {
			return head.insert(node);
		}
	}
	
	public boolean delete(NodeSeznam node) {
		if (head == null) {
			return false;
		} 
		else if (head.compare(node) == 0) {
			this.head = head.getNext();
			return true;
		} else 
		{
			return head.delete(node);
		}
	}
	
	public NodeSeznam getNext() {
		return this.head;
	}
	
	public boolean search(NodeSeznam node) {
		if (this.compare(node) == 0) 
		{
			return true;
		} else if (head == null) 
		{
			return false;
		} else {
			
			return head.search(node);
		}
	}
	
	public int compare(NodeSeznam node) {
		counter++;
		return node.key - this.key;
	}
	
	public int getCounter() {
		return counter;
	}
	
	public void resetCounter() {
		counter=0;
	}
}