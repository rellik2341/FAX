package aps2.editdistance;

public class EditAction {
	private enum Action {INS, DEL, SUB};
	private Action action;
	private int pos;
	private char c;
	
	/**
	 * Ta funkcija naj bo obratna funkciji toString.
	 * @param s - String, sestavljen iz akcije, dodatnega znaka, polo�aja in " "
	 */
	public EditAction(String s){
		char  op = s.charAt(0);
		if(op == 'I'){
			action= Action.INS;
			c= s.charAt(1);
			pos= Integer.parseInt(s.substring(2,s.length()-1));
		}
		else if(op == 'D'){
			action= Action.DEL;
			pos= Integer.parseInt(s.substring(1,s.length()-1));
		}
		else if(op == 'S'){
			action= Action.SUB;
			c= s.charAt(1);
			pos= Integer.parseInt(s.substring(2,s.length()-1));
		}

	}
	public String toString(){
		switch(action){
			case INS: return "I"+c+pos+" ";
			case DEL: return "D"+pos+" ";
			case SUB: return "S"+c+pos+" ";
		}
		return "";
	}
	
	/**
	 * Uporabi EditAction na nizu
	 * @param s vhodni niz
	 * @return predelan vhodni niz
	 */
	public String apply(String s){
		if(action == Action.INS){
			String suffix ="";
				String prefix = s.substring(0, pos);
			if(pos < s.length()){
			suffix = s.substring(pos); 
			}
			else return s+c;
			return prefix + c + suffix; 
			}
		
		if(action == Action.DEL){
			String suffix ="";
				String prefix = s.substring(0, pos);
			if(pos < s.length()){
			suffix = s.substring(pos+1); 
			}
			return prefix + suffix; 
			}
		if(action == Action.SUB){
			String suffix ="";
				String prefix = s.substring(0, pos);
			if(pos < s.length()){
			suffix = s.substring(pos+1); 
			}
			return prefix + c + suffix; 
			}
			return "";

	
			
		

	}
}
