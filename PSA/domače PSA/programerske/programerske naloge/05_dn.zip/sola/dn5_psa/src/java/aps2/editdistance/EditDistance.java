package aps2.editdistance;

import java.util.Vector;

import javax.swing.text.html.MinimalHTMLWriter;

public class EditDistance {
	EditDistance(){
	}
	/**
	 * Poi��e najkraj�e zaporedje akcij, ki niz a spremenijo v niz b. 
	 *   �e do enako dolgega zaporedja lahko privede ve� razli�nih akcij,
	 *   se najprej uporabi zamenjava, nato vstavljanje, na koncu brisanje. 
	 * @param a - za�etni niz
	 * @param b - kon�ni niz
	 * @return - najkraj�e zaporedje akcij, ki spremenijo a v b
	 */
	public static Vector<EditAction> findTransform(String a, String b){
		Vector<EditAction> res = new Vector<EditAction>();
		
		int x = a.length();
		int y = b.length();
		int tab [][]= new int [x+1][y+1];
		for(int i=0;i<tab.length;i++){
			for(int j=0;j<tab[0].length;j++){
				if(i==0) tab[i][j]=j;
				else if(j==0)  tab[i][j]=i;
				else{
				if(b.charAt(j-1)==a.charAt(i-1)) tab[i][j]=tab[i-1][j-1];
				else{ 
					int p = Math.min(tab[i-1][j-1], tab[i][j-1]);
					int min = Math.min(p, tab[i-1][j]);
					tab[i][j]=min+1;
				}
				}
			}
		}

		  int i=x;
		  int j=y;
		  while(true)
		  {
			if(i==0 && j==0)return res;
				
				else if(i==0){j=j-1;res.add(new EditAction("I"+b.charAt(j)+i+" "));}
				else if(j==0){res.add(new EditAction("D"+i+" "));i=i-1;}
				else if(tab[i][j]==tab[i-1][j-1]){i=i-1;j=j-1;}	
		 
		   else
		   {
			if(tab[i][j-1]<tab[i-1][j]){
						if(tab[i][j-1]<tab[i-1][j-1])
						{j=j-1;res.add(new EditAction("I"+b.charAt(j)+i+" ")); }
						else{j=j-1;i=i-1;res.add(new EditAction("S"+b.charAt(j)+i+" ")); }
					}
					else{
						if(tab[i-1][j]<tab[i-1][j-1]){
							res.add(new EditAction("D"+i+" "));i=i-1;
						}
					else{i=i-1;j=j-1;res.add(new EditAction("S"+b.charAt(j)+i+" ")); }
					}	
				
					}}
				}
	
		
	
	public static String transformToString(Vector<EditAction>actions){
		String s = "";
		for (EditAction i:actions){
			  if(!i.equals(""))
			   {
			   s += i;
			   }
		}
		return s;
	}
	public static  Vector<EditAction> stringToTransform(String s){
		Vector<EditAction> res = new Vector<EditAction>();
		for (String a : s.split(" ")) 
		  {
		   res.add(new EditAction(a+" "));
		  }
		return res;		
	}
	public static String doTransform(String a, Vector<EditAction>actions){
		for (EditAction i:actions){
			  if(!a.equals(""))
			a = i.apply(a);
		}
		return a;
	}
}
