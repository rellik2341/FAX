package aps2.editdistance;


import java.util.Vector;

import aps2.editdistance.EditDistance;
import junit.framework.TestCase;

/**
 * insert Public Tests to this class. Public tests are written by the Instructor
 * and may be used for grading projects. This source code is made available to
 * students.
 */

public class PublicTests extends TestCase {
	protected void setUp() throws Exception {
	}
	public void testEditInsert() throws Exception{
		String s = "";
		EditAction a=new EditAction("Ia0 ");
		s = a.apply(s);
		a=new EditAction("Ib0 ");
		s = a.apply(s);
		a=new EditAction("Ic0 ");
		s = a.apply(s);
		a=new EditAction("Id3 ");
		s = a.apply(s);
		assertTrue(s.equals("cbad"));
	}
	public void testEditDelete() throws Exception{
		String s = "Programiranje";
		EditAction a=new EditAction("D0 ");
		s = a.apply(s);
		a=new EditAction("D2 ");
		s = a.apply(s);
		a=new EditAction("D10 ");
		s = a.apply(s);
		a=new EditAction("D3 ");
		s = a.apply(s);
		assertTrue(s, s.equals("rormiranj"));
	}
	public void testEditSubstitute() throws Exception{
		String s = "warcraft";
		EditAction a=new EditAction("Ss0 ");
		s = a.apply(s);
		a=new EditAction("Sm3 ");
		s = a.apply(s);
		a=new EditAction("So5 ");
		s = a.apply(s);
		a=new EditAction("Si7 ");
		s = a.apply(s);
		assertTrue(s, s.equals("sarmrofi"));		
	}
	public void testApplyMultipleEdits() throws Exception{
		Vector<EditAction> actions = EditDistance.stringToTransform("Ir0 Ia1 Sz2 Ss3 ");
		/* System.out.println(EditDistance.transformToString(EditDistance.findTransform("brodnik", "razsodnik"))); */
		String s = EditDistance.doTransform("brodnik", actions);
		assertTrue(s, s.equals("razsodnik"));
	}
	public void testFindSomeTransform() throws Exception{
		Vector<EditAction> actions = EditDistance.findTransform(
				"luna sije", "njam, po mije");
		String s = EditDistance.doTransform("luna sije", actions);
		assertTrue(s, s.equals("njam, po mije"));	
	}
	
}
