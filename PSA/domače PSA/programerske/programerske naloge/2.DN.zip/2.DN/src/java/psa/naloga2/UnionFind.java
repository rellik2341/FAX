package psa.naloga2;

import java.util.Vector;

public class UnionFind {
	public int[] id;

	public UnionFind(int N) {
		id=new int [N];
		for (int i = 0; i<N; i++){
		id[i] = i;
			}
	}

	/*
	 * Metoda sprejme index in vrne predstavnika mnozice, katere clan je index.
	 */
	
	public int find(int i) {
		Vector<Integer> v = new Vector<Integer>(); 
		while(id[i] != i) {
			v.add(i);
			i = id[i];
		}
		for (int elt : v) {
			id[elt] = i;
		}
		return i;
	}

	/*
	 * Metoda sprejme da indexa in naredi unijo
	 */
	
	public void unite(int p, int q) {
		int un=find(p);
		id[q]=un;
	}
	
	/*
	 * Metoda vrne true, ce sta p in q v isti mnozici
	 */

	public boolean isInSameSet(int p, int q) {
		if(find(p)==find(q))return true;
		else return false;
	}
}